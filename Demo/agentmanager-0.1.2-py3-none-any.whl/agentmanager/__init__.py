__version__ = "0.1.2"
__author__ = "Nilavo Boral"

from .manager import CloudAgentManager