from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_openai import ChatOpenAI
from langchain_ollama import ChatOllama
from langchain_groq import ChatGroq
from langchain_mistralai import ChatMistralAI
from langchain_nvidia_ai_endpoints import ChatNVIDIA

model_registry = {
    "Google": {
        "models": ["gemini-2.5-flash", "gemini-2.5-pro"],
        "env_key": "GOOGLE_API_KEY",
        "get_key_link": "https://aistudio.google.com/app/api-keys",
        "class": ChatGoogleGenerativeAI,
        "init_args": {"max_retries": 2}
    },
    "OpenAI": {
        "models": ["gpt-5-nano", "gpt-5-mini", "gpt-4o-mini", "gpt-3.5-turbo", "gpt-4.1-mini", "gpt-4.1", "gpt-5"],
        "env_key": "OPENAI_API_KEY",
        "get_key_link": "https://platform.openai.com/api-keys",
        "class": ChatOpenAI,
        "init_args": {"max_retries": 2}
    },
    "Ollama": {
        "models": [
            "gpt-oss:20b-cloud", "gpt-oss:120b-cloud",
            "deepseek-v3.1:671b-cloud",
            "kimi-k2:1t-cloud",
            "qwen3-coder:480b-cloud",
            "glm-4.6:cloud",
            "minimax-m2:cloud" # 230b
            ],
        "env_key": "OLLAMA_API_KEY",
        "get_key_link": "https://ollama.com/settings/keys",
        "class": ChatOllama,
        "init_args": {
            "max_retries": 2,
            "base_url": "https://ollama.com"
        }
    },
    "Groq": {
        "models": [
            "openai/gpt-oss-20b", "openai/gpt-oss-120b", "openai/gpt-oss-safeguard-20b",
            "llama-3.1-8b-instant", "llama-3.3-70b-versatile", "meta-llama/llama-4-maverick-17b-128e-instruct", "meta-llama/llama-4-scout-17b-16e-instruct",
            # "groq/compound", "groq/compound-mini", # tool calling is not supported
            "moonshotai/kimi-k2-instruct", "moonshotai/kimi-k2-instruct-0905"
            ],
        "env_key": "GROQ_API_KEY",
        "get_key_link": "https://console.groq.com/keys",
        "class": ChatGroq,
        "init_args": {"max_retries": 2}
    },
    "Mistral": {
        "models": [
            # "ministral-3b-2410", "ministral-8b-2410", # small models
            "mistral-tiny-2407", "voxtral-mini-2507",
            "pixtral-12b",
            "mistral-small-2506", "voxtral-small-2507", "devstral-small-2507", "magistral-small-2509", 
            "codestral-2508",
            "mistral-medium", "devstral-medium-2507", "magistral-medium-2509",
            "pixtral-large-2411", "mistral-large-latest"
            ],
        "env_key": "MISTRAL_API_KEY",
        "get_key_link": "https://console.mistral.ai/build/playground?workspace_dialog=apiKeys&workspace_dialog_expanded=true",
        "class": ChatMistralAI,
        "init_args": {"max_retries": 2}
    },
    "Nvidia": {
        "models": ['abacusai/dracarys-llama-3.1-70b-instruct', 'ai21labs/jamba-1.5-mini-instruct', 'baichuan-inc/baichuan2-13b-chat', 'bytedance/seed-oss-36b-instruct', 'deepseek-ai/deepseek-r1', 'deepseek-ai/deepseek-r1-0528', 'deepseek-ai/deepseek-r1-distill-llama-8b', 'deepseek-ai/deepseek-r1-distill-qwen-14b', 'deepseek-ai/deepseek-r1-distill-qwen-32b', 'deepseek-ai/deepseek-r1-distill-qwen-7b', 'deepseek-ai/deepseek-v3.1', 'deepseek-ai/deepseek-v3.1-terminus', 'google/gemma-3-1b-it', 'google/gemma-3-27b-it', 'google/gemma-3-4b-it', 'google/gemma-3n-e2b-it', 'google/gemma-3n-e4b-it', 'google/gemma-7b', 'gotocompany/gemma-2-9b-cpt-sahabatai-instruct', 'ibm/granite-3.3-8b-instruct', 'ibm/granite-guardian-3.0-8b', 'igenius/italia_10b_instruct_16k', 'institute-of-science-tokyo/llama-3.1-swallow-8b-instruct-v0.1', 'marin/marin-8b-instruct', 'mediatek/breeze-7b-instruct', 'meta/llama-3.1-405b-instruct', 'meta/llama-3.1-70b-instruct', 'meta/llama-3.1-8b-instruct', 'meta/llama-3.2-11b-vision-instruct', 'meta/llama-3.2-1b-instruct', 'meta/llama-3.2-3b-instruct', 'meta/llama-3.2-90b-vision-instruct', 'meta/llama-3.3-70b-instruct', 'meta/llama-4-maverick-17b-128e-instruct', 'meta/llama-4-scout-17b-16e-instruct', 'meta/llama3-70b-instruct', 'meta/llama3-8b-instruct', 'microsoft/phi-3-medium-128k-instruct', 'microsoft/phi-3-medium-4k-instruct', 'microsoft/phi-3-mini-128k-instruct', 'microsoft/phi-3-mini-4k-instruct', 'microsoft/phi-3-small-128k-instruct', 'microsoft/phi-3-small-8k-instruct', 'microsoft/phi-3.5-mini-instruct', 'microsoft/phi-3.5-vision-instruct', 'microsoft/phi-4-mini-flash-reasoning', 'microsoft/phi-4-mini-instruct', 'microsoft/phi-4-multimodal-instruct', 'mistralai/codestral-22b-instruct-v0.1', 'mistralai/magistral-small-2506', 'mistralai/mamba-codestral-7b-v0.1', 'mistralai/mathstral-7b-v0.1', 'mistralai/ministral-14b-instruct-2512', 'mistralai/mistral-7b-instruct-v0.2', 'mistralai/mistral-7b-instruct-v0.3', 'mistralai/mistral-large-3-675b-instruct-2512', 'mistralai/mistral-medium-3-instruct', 'mistralai/mistral-nemotron', 'mistralai/mistral-small-24b-instruct', 'mistralai/mistral-small-3.1-24b-instruct-2503', 'mistralai/mixtral-8x22b-instruct-v0.1', 'mistralai/mixtral-8x7b-instruct-v0.1', 'moonshotai/kimi-k2-instruct', 'moonshotai/kimi-k2-instruct-0905', 'nvidia/llama-3.1-nemoguard-8b-content-safety', 'nvidia/llama-3.1-nemoguard-8b-topic-control', 'nvidia/llama-3.1-nemotron-nano-4b-v1.1', 'nvidia/llama-3.1-nemotron-nano-8b-v1', 'nvidia/llama-3.1-nemotron-nano-vl-8b-v1', 'nvidia/llama-3.1-nemotron-safety-guard-8b-v3', 'nvidia/llama-3.1-nemotron-ultra-253b-v1', 'nvidia/llama-3.3-nemotron-super-49b-v1', 'nvidia/llama-3.3-nemotron-super-49b-v1.5', 'nvidia/nemotron-4-mini-hindi-4b-instruct', 'nvidia/nemotron-mini-4b-instruct', 'nvidia/nemotron-nano-12b-v2-vl', 'nvidia/nvidia-nemotron-nano-9b-v2', 'nvidia/riva-translate-4b-instruct', 'nvidia/usdcode-llama-3.1-70b-instruct', 'nvidia/vila', 'openai/gpt-oss-120b', 'openai/gpt-oss-120b', 'openai/gpt-oss-20b', 'openai/gpt-oss-20b', 'qwen/qwen2-7b-instruct', 'qwen/qwen2.5-7b-instruct', 'qwen/qwen2.5-coder-32b-instruct', 'qwen/qwen2.5-coder-7b-instruct', 'qwen/qwen3-235b-a22b', 'qwen/qwen3-coder-480b-a35b-instruct', 'qwen/qwen3-next-80b-a3b-instruct', 'qwen/qwen3-next-80b-a3b-thinking', 'qwen/qwq-32b', 'rakuten/rakutenai-7b-chat', 'rakuten/rakutenai-7b-instruct', 'sarvamai/sarvam-m', 'speakleash/bielik-11b-v2.3-instruct', 'speakleash/bielik-11b-v2.6-instruct', 'stockmark/stockmark-2-100b-instruct', 'thudm/chatglm3-6b', 'tiiuae/falcon3-7b-instruct', 'tokyotech-llm/llama-3-swallow-70b-instruct-v0.1', 'upstage/solar-10.7b-instruct', 'utter-project/eurollm-9b-instruct'],
        "env_key": "NVIDIA_API_KEY",
        "get_key_link": "https://build.nvidia.com/settings/api-keys",
        "class": ChatNVIDIA,
        "init_args": {"max_retries": 2}
    },
}
